
package restaurent;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


public class sql {
Connection conn;
PreparedStatement stmt;
ResultSet rs;
String host="jdbc:derby://localhost:1527/Ritik";
String user="IS2560";
String pass="IS2560";
int visiting;
String[] custlogin(String un, String ps){
    String sha = org.apache.commons.codec.digest.DigestUtils.sha256Hex(ps);
   
    try{
        conn = DriverManager.getConnection(host,user,pass);
        stmt = conn.prepareStatement("select * from is2560.customer");
        rs = stmt.executeQuery();
        
        while (rs.next()){
            String usernm = rs.getString("USERNAME");
            String passwd = rs.getString("PASSWORD");
            String cusname = rs.getString("NAME");
            int vt = rs.getInt("VISTING_TIME")+1;
            if (usernm.equals(un) && passwd.equals(sha)){
                Statement stmt1 = conn.createStatement();
                String strt=("update is2560.customer set visting_time = "+vt+" where username = \'"+usernm+"\'");
                stmt1.executeUpdate(strt);
                String[] list = {"true",cusname,usernm};
                return list;
            }
        }
        String[] list = {"false","0"};
        return list;
    }catch(SQLException exx){
        JOptionPane.showMessageDialog(null, exx.getMessage());
    }
    String[] list = {"false","0"};
        return list;
}
    
    void custsign(String usernm, String pwd,String name){
        String sha = org.apache.commons.codec.digest.DigestUtils.sha256Hex(pwd);
        try{
            conn = DriverManager.getConnection(host,user,pass);
            stmt = conn.prepareStatement("insert into is2560.customer values (?,?,?,?,?)");
            stmt.setString(1, usernm);
            stmt.setString(2, name);
            stmt.setInt(3, 0);
            stmt.setInt(4, 0);
            stmt.setString(5,sha);
            stmt.executeUpdate();
        }catch(SQLException exx){
            JOptionPane.showMessageDialog(null, exx.getMessage());
        }
    }
    boolean adminlogin(String un, String ps){
        String sha = org.apache.commons.codec.digest.DigestUtils.sha512Hex(ps);
    try{
        conn = DriverManager.getConnection(host,user,pass);
        stmt = conn.prepareStatement("select * from is2560.employee");
        
        rs = stmt.executeQuery();
        
        while (rs.next()){
            String usernm = rs.getString("USERNAME");
            String passwd = rs.getString("PASSWORD");
            if (usernm.equals(un) && passwd.equals(sha)){
                return true;
            }
        }
        return false;
    }catch(SQLException exx){
        JOptionPane.showMessageDialog(null, exx.getMessage());
    }
    return false;
}
    void newstaff(String id,String name, String desig){
        try{
            conn = DriverManager.getConnection(host, user, pass);
            stmt = conn.prepareStatement("insert into is2560.staff values (?,?,?)");
            stmt.setString(1, id);
            stmt.setString(2, name);
            stmt.setString(3,desig);
            
            stmt.executeUpdate();
            
        }catch(SQLException exx){
            JOptionPane.showMessageDialog(null, exx.getMessage());
        }
    }
        void deletestaff(String id){
        try{
            conn = DriverManager.getConnection(host, user, pass);
            stmt = conn.prepareStatement("Delete from is2560.staff where id_no =?");
            stmt.setString(1, id);

            stmt.executeUpdate();
            
        }catch(SQLException exx){
            JOptionPane.showMessageDialog(null, exx.getMessage());
        }
    }
    void updatestaff(String id,String name, String desig){
        try{
            conn = DriverManager.getConnection(host, user, pass);
            stmt = conn.prepareStatement("update is2560.staff set name = ?, designation=? where id_no = ?");
            stmt.setString(1, name);
            stmt.setString(2, desig);
            stmt.setString(3,id);
            
            stmt.executeUpdate();
            
        }catch(SQLException exx){
            JOptionPane.showMessageDialog(null, exx.getMessage());
        }
    }
    void updatemenu(String id,String name, int price){
        try{
            conn = DriverManager.getConnection(host, user, pass);
            stmt = conn.prepareStatement("update is2560.menu set name = ?, price=? where id = ?");
            stmt.setString(1, name);
            stmt.setInt(2, price);
            stmt.setString(3,id);
            
            stmt.executeUpdate();
            
        }catch(SQLException exx){
            JOptionPane.showMessageDialog(null, exx.getMessage());
        }
    }
    void deletemenu(String id){
        try{
            conn = DriverManager.getConnection(host, user, pass);
            stmt = conn.prepareStatement("Delete from is2560.menu where id =?");
            stmt.setString(1, id);

            stmt.executeUpdate();
            
        }catch(SQLException exx){
            JOptionPane.showMessageDialog(null, exx.getMessage());
        }
    }
        void newmenu(String id,String name, int price){
        try{
            conn = DriverManager.getConnection(host, user, pass);
            stmt = conn.prepareStatement("insert into is2560.menu values (?,?,?)");
            stmt.setString(1, id);
            stmt.setString(2, name);
            stmt.setInt(3,price);
            
            stmt.executeUpdate();
            
        }catch(SQLException exx){
            JOptionPane.showMessageDialog(null, exx.getMessage());
        }
    }
    void biller(String username,double total){
        try{
            conn = DriverManager.getConnection(host, user, pass);
            stmt = conn.prepareStatement("UPDATE IS2560.CUSTOMER SET \"EARNING\" = EARNING+? WHERE USERNAME = ?");
            stmt.setDouble(1, total);
            stmt.setString(2,username);
            
            stmt.executeUpdate();
            
        }catch(SQLException exx){
            JOptionPane.showMessageDialog(null, exx.getMessage());
        }  
    }
    void feed(String saying, int star){
        try{
            conn = DriverManager.getConnection(host, user, pass);
            stmt = conn.prepareStatement("insert into is2560.feedback values (?,?,?,?)");
            
            stmt.setString(1, saying);
            Date date = new Date();
            String time = String.format("%02d:%02d:%02d", date.getHours(),date.getMinutes(),date.getSeconds());
            stmt.setString(2, time);
            DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String date1 = sdf.format(date);
            stmt.setString(3, date1);
            stmt.setInt(4, star);
            stmt.executeUpdate();
        }catch(SQLException exx){
            JOptionPane.showMessageDialog(null, exx.getMessage());
        }
    }
    int price(String name){
        try{
            conn = DriverManager.getConnection(host,user,pass);
            stmt = conn.prepareStatement("select price from is2560.menu where NAME = ?");
            stmt.setString(1, name);
            
            rs = stmt.executeQuery();
            while(rs.next()){
                int p = rs.getInt("price");
                return p;
            }
        }catch(SQLException exx){
            JOptionPane.showMessageDialog(null, exx.getMessage());
        }
        return 0;
    }


}
