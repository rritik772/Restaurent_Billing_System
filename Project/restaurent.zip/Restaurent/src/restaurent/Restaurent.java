package restaurent;
public class Restaurent {

    public static void main(String[] args) {
       mainScreen.main(args);
       //R_Admin ra = new R_Admin();
       //ra.setVisible(true);
       //customerlogin.main(args);
       //customersignup.main(args);
       //adminlogin.main(args);
       //StaffManager.main(args);
       //tablebooking.main(args);
        //oder o = new oder("hello","hello");
        //o.setVisible(true);
       //welcome n = new welcome("hero","zero");
       //n.setVisible(true);
       //feedb fb = new feedb();
       //fb.setVisible(true);
    }

}
